package com.wordpress.ideatodaybt.plc.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;
import com.wordpress.ideatodaybt.plc.R;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

public class AdpActivity extends AppCompatActivity implements View.OnClickListener {
    protected EditText edtNam, edtTyp,edtStr;
    protected Button btndn;
    protected ProgressDialog progressDialog;
    private DatabaseReference mData;
    private DatabaseReference mDat;
    private StorageReference mStorage;
    private DatabaseReference mDataUser;
    Context context;
    private FirebaseAuth mAuth;
    String mCurrent, name,ptype, pstr, puid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adp);
        edtNam = (EditText)findViewById(R.id.input_headline);
        edtTyp = (EditText)findViewById(R.id.input_nptype);
        edtStr = (EditText)findViewById(R.id.input_news);
        btndn = (Button)findViewById(R.id.btn_news);
        mAuth = FirebaseAuth.getInstance();
        mCurrent = mAuth.getCurrentUser().getUid();
        puid = UUID.randomUUID().toString();
        mData = FirebaseDatabase.getInstance().getReference().child("Products").child(puid);
        mDat = FirebaseDatabase.getInstance().getReference().child("Introduction").child(puid);

        btndn.setOnClickListener(this);

        mStorage = FirebaseStorage.getInstance().getReference();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_news)
        {
            varInt();
            CropImage.activity()
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1,1)
                    .start(AdpActivity.this);
        }

    }
    public void varInt()
    {
        name = edtNam.getText().toString();
        ptype = edtTyp.getText().toString();
        pstr =  edtStr.getText().toString();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                progressDialog = new ProgressDialog(AdpActivity.this);
                progressDialog.setTitle("PLC");
                progressDialog.setMessage("Adding new Product: " + name);
                progressDialog.setIndeterminate(true);
                progressDialog.setCancelable(false);
                progressDialog.show();
                Uri resultUri = result.getUri();

//                File thumb_filepa = new File(resultUri.getPath());
//
//                try {
//                    Bitmap thumb_bitmap = new Compressor(RepDisActivity.this)
//                            .setMaxHeight(200)
//                            .setMaxWidth(200)
//                            .setQuality(75)
//                            .compressToBitmap(thumb_filepa);
//                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                    thumb_bitmap.compress(Bitmap.CompressFormat.JPEG,100,baos);
//                    thumb_data = baos.toByteArray();
//
//                } catch (IOException e) {
//                    Toast.makeText(RepDisActivity.this,"Error2: " + e.toString(),Toast.LENGTH_LONG).show();
//                }

                StorageReference filepath = mStorage.child("products").child(puid + ".jpg");

                filepath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful())
                        {
                            final String downUri = task.getResult().getDownloadUrl().toString();
                            final String tstamp = DateFormat.getDateTimeInstance().format(new Date());
                            HashMap<String,String> repMap = new HashMap<>();
                            repMap.put("product_name",name);
                            repMap.put("product_date",tstamp);
                            repMap.put("product_status",ptype);
                            repMap.put("product_type",ptype);
                            repMap.put("product_revenue","0");
                            repMap.put("product_str",pstr);

                            repMap.put("image",downUri);
                            mData.setValue(repMap).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    HashMap<String, String> statmap = new HashMap<>();
                                    statmap.put("product_name",name);
                                    statmap.put("product_date", tstamp);
                                    statmap.put("image",downUri);
                                    mDat.setValue(statmap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful())
                                            {
                                                edtNam.setText("");
                                                edtStr.setText("");
                                                edtTyp.setText("");
                                                progressDialog.dismiss();
                                                Toast.makeText(AdpActivity.this, "Product added successfully",Toast.LENGTH_LONG).show();
                                            }
                                            else{
                                                progressDialog.dismiss();
                                                Toast.makeText(AdpActivity.this,"Failed to add product",Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                                }
                            });

                        }
                        else{
                            progressDialog.dismiss();
                            Toast.makeText(AdpActivity.this,"Failed to add new product ",Toast.LENGTH_LONG).show();
                        }

                    }
                });
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Toast.makeText(AdpActivity.this,"Failed to attach picture: ", Toast.LENGTH_LONG).show();
            }
        }
    }
}
