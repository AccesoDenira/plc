package com.wordpress.ideatodaybt.plc.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.wordpress.ideatodaybt.plc.R;


public class LoginActivity extends AppCompatActivity {
    protected EditText edtEmail, edtPass;
    protected Button btnlgn;
    private DatabaseReference mDataref;
    private String email,pass,status;
    private Boolean chkbol;
    private FirebaseAuth mAuth;
    protected ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        edtEmail = (EditText)findViewById(R.id.input_email);
        edtPass = (EditText)findViewById(R.id.input_password);
        btnlgn = (Button)findViewById(R.id.btn_login);
        FirebaseApp.initializeApp(LoginActivity.this);
        mAuth = FirebaseAuth.getInstance();

        mDataref = FirebaseDatabase.getInstance().getReference().child("Admins");

        btnlgn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                varInit();
                checkErr();
                if (chkbol)
                {
                    progressDialog = new ProgressDialog(LoginActivity.this);
                    progressDialog.setTitle("PLC");
                    progressDialog.setMessage("Logging into account as " + email);
                    progressDialog.setIndeterminate(false);
                    progressDialog.setCancelable(true);
                    progressDialog.show();
                    LogClass(email,pass);
                }
            }
        });

    }
    public void varInit()
    {
        email = edtEmail.getText().toString();
        pass = edtPass.getText().toString();
    }

    public void checkErr(){
        chkbol = true;
        if (email.isEmpty() && !(email.contains("@")))
        {
            edtEmail.setError("Invalid email!");
            chkbol = false;
        }
        if (pass.isEmpty()){
            edtPass.setError("Invalid password!");
            chkbol = false;
        }
    }

    private void LogClass(final String a, final String b){
        mAuth.signInWithEmailAndPassword(a,b).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressDialog.dismiss();
                if (task.isSuccessful())
                {
                    Intent lgIntent = new Intent(LoginActivity.this, HomeActivity.class);
                    lgIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    lgIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(lgIntent);

                }
                else{
                    Toast.makeText(LoginActivity.this,"Login failed please try again", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

}
