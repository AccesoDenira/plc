package com.wordpress.ideatodaybt.plc.Activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.squareup.picasso.Picasso;
import com.wordpress.ideatodaybt.plc.Model.Products;
import com.wordpress.ideatodaybt.plc.R;


import de.hdodenhof.circleimageview.CircleImageView;

public class ProdsActivity extends AppCompatActivity {
    protected RecyclerView rec_user;
    private DatabaseReference mDatabaseref;
    private FirebaseUser mCurrent;
    private DatabaseReference mDataStat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prods);
        rec_user = (RecyclerView)findViewById(R.id.recy_users);
        rec_user.setHasFixedSize(true);
        rec_user.setLayoutManager(new LinearLayoutManager(ProdsActivity.this));
        mDatabaseref = FirebaseDatabase.getInstance().getReference().child("Products");
        mCurrent = FirebaseAuth.getInstance().getCurrentUser();
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<Products,UsersViewHolder> fbryc  = new FirebaseRecyclerAdapter<Products, UsersViewHolder>(
                Products.class,
                R.layout.user_hukup,
                UsersViewHolder.class,
                mDatabaseref
        ) {
            @Override
            protected void populateViewHolder(UsersViewHolder viewHolder, Products model, int position) {
                final String user = getRef(position).getKey();

                viewHolder.setName(model.getProduct_name());
                viewHolder.setStat(model.getProduct_date());
                viewHolder.setProPic(model.getImage());

                viewHolder.mView.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        CharSequence options[] = new CharSequence[]{"Product Info","Record Sale","Market Details"};
                        AlertDialog.Builder builder = new AlertDialog.Builder(ProdsActivity.this);
                        builder.setTitle("Select Option");
                        builder.setItems(options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == 0)
                                {

                                }
                                if (which == 1)
                                {
                                    //chat Activity

                                }
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                });
            }
        };
        rec_user.setAdapter(fbryc);
    }

    public static class UsersViewHolder extends RecyclerView.ViewHolder{

        View mView;

        public UsersViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

        }
        public void setName(String name)
        {
            TextView textUser = (TextView) mView.findViewById(R.id.txtUsern);
            textUser.setText(name);

        }
        public void setStat(String status){
            TextView textStat = (TextView)mView.findViewById(R.id.txtHsat);
            textStat.setText(status);
        }

        public void setProPic(String thumb_image){
            CircleImageView circ = (CircleImageView)mView.findViewById(R.id.huk_pic);
            Picasso.get().load(thumb_image).placeholder(R.drawable.rgt).into(circ);
        }

    }

}
