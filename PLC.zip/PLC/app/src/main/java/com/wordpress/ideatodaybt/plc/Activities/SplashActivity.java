package com.wordpress.ideatodaybt.plc.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.wordpress.ideatodaybt.plc.R;

public class SplashActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        Thread timer = new Thread(){
            @Override
            public void run() {
                try
                {
                    sleep(5000);
                }

                catch (Exception e)

                {

                }
                finally {
                    if (mUser == null)
                    {
                        Intent lgInt = new Intent(SplashActivity.this, LoginActivity.class);
                        startActivity(lgInt);
                    }
                    else{
                        Intent lgInt = new Intent(SplashActivity.this, HomeActivity.class);
                        startActivity(lgInt);
                    }
                }
            }
        };timer.start();

    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
