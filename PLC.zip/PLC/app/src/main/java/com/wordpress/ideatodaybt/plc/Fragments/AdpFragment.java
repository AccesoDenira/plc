package com.wordpress.ideatodaybt.plc.Fragments;


import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ServerValue;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.wordpress.ideatodaybt.plc.R;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;


import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.app.Activity.RESULT_OK;


/**
 * A simple {@link Fragment} subclass.
 */
public class AdpFragment extends Fragment implements View.OnClickListener {
    protected EditText edtNam, edtTyp,edtStr;
    protected Button btndn;
    private DatabaseReference mData;
    private DatabaseReference mDat;
    private StorageReference mStorage;
    private DatabaseReference mDataUser;
    Context context;
    private FirebaseAuth mAuth;
    String mCurrent, name,ptype, pstr, puid;

    public AdpFragment() {
        // Required empty public constructor
    }

    public static AdpFragment newInstance() {
        AdpFragment fragment = new AdpFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.activity_adp, container, false);
        context = getActivity().getApplicationContext();
        edtNam = (EditText)rootView.findViewById(R.id.input_headline);
        edtTyp = (EditText)rootView.findViewById(R.id.input_nptype);
        edtStr = (EditText)rootView.findViewById(R.id.input_news);
        btndn = (Button)rootView.findViewById(R.id.btn_news);
        mAuth = FirebaseAuth.getInstance();
        mCurrent = mAuth.getCurrentUser().getUid();
        mData = FirebaseDatabase.getInstance().getReference().child("Products").push();
        puid = mData.getKey();
        mDat = FirebaseDatabase.getInstance().getReference().child("Introduction").child(puid);

        btndn.setOnClickListener(this);

        mStorage = FirebaseStorage.getInstance().getReference();
        return rootView;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_news)
        {
            varInt();
            Toast.makeText(context, "Uploading product please wait",Toast.LENGTH_LONG).show();
            CropImage.activity()
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1,1)
                    .start(getActivity());
        }

    }

    public void varInt()
    {
        name = edtNam.getText().toString();
        ptype = edtTyp.getText().toString();
        pstr =  edtStr.getText().toString();
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(context, "On Activity result",Toast.LENGTH_LONG).show();
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();

//                File thumb_filepa = new File(resultUri.getPath());
//
//                try {
//                    Bitmap thumb_bitmap = new Compressor(RepDisActivity.this)
//                            .setMaxHeight(200)
//                            .setMaxWidth(200)
//                            .setQuality(75)
//                            .compressToBitmap(thumb_filepa);
//                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                    thumb_bitmap.compress(Bitmap.CompressFormat.JPEG,100,baos);
//                    thumb_data = baos.toByteArray();
//
//                } catch (IOException e) {
//                    Toast.makeText(RepDisActivity.this,"Error2: " + e.toString(),Toast.LENGTH_LONG).show();
//                }

                StorageReference filepath = mStorage.child("products").child(puid + ".jpg");

                filepath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful())
                        {
                            final String downUri = task.getResult().getDownloadUrl().toString();
                            final String tstamp = ServerValue.TIMESTAMP.toString();
                            HashMap<String,String> repMap = new HashMap<>();
                            repMap.put("product_name",name);
                            repMap.put("product_date",tstamp);
                            repMap.put("product_status",ptype);
                            repMap.put("product_type",ptype);
                            repMap.put("product_revenue","0");
                            repMap.put("product_str",pstr);

                            repMap.put("image",downUri);
                            mData.setValue(repMap).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    HashMap<String, String> statmap = new HashMap<>();
                                    statmap.put("product_name",name);
                                    statmap.put("product_date", tstamp);
                                    statmap.put("image",downUri);
                                    mDat.setValue(statmap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful())
                                            {
                                                edtNam.setText("");
                                                edtStr.setText("");
                                                edtTyp.setText("");
                                                Toast.makeText(context, "report sent",Toast.LENGTH_LONG).show();
                                            }
                                            else{
                                                Toast.makeText(context,"Failed to send report: ",Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                                }
                            });

                        }
                        else{
                            Toast.makeText(context,"Failed to send report: ",Toast.LENGTH_LONG).show();
                        }

                    }
                });
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Toast.makeText(context,"Failed to attach picture: ", Toast.LENGTH_LONG).show();
            }
        }
    }



}
