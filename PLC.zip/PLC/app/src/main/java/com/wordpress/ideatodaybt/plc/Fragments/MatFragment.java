package com.wordpress.ideatodaybt.plc.Fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wordpress.ideatodaybt.plc.R;


/**
 * Created by NDT on 4/3/2018.
 */

public class MatFragment extends Fragment {

    public MatFragment() {
        // Required empty public constructor
    }


    public static MatFragment newInstance() {
        MatFragment fragment = new MatFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    Context context;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_mat, container, false);

        return rootView;
    }

}
