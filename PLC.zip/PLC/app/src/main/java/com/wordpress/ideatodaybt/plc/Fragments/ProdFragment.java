package com.wordpress.ideatodaybt.plc.Fragments;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;
import com.wordpress.ideatodaybt.plc.Model.IntroProducts;
import com.wordpress.ideatodaybt.plc.Model.Products;
import com.wordpress.ideatodaybt.plc.R;

import de.hdodenhof.circleimageview.CircleImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ProdFragment extends Fragment {
    protected RecyclerView recy;
    private DatabaseReference mData;
    private DatabaseReference mDataUser;
    Context context;
    private FirebaseAuth mAuth;
    String mCurrent, username;

    public ProdFragment() {
        // Required empty public constructor
    }
    public static ProdFragment newInstance() {
        ProdFragment fragment = new ProdFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.activity_prods, container, false);
        context = getActivity().getApplicationContext();
        recy = (RecyclerView)rootView.findViewById(R.id.recy_users);

        mAuth = FirebaseAuth.getInstance();
        mCurrent = mAuth.getCurrentUser().getUid();
        mData = FirebaseDatabase.getInstance().getReference().child("Products");
        mData.keepSynced(true);
        recy.setHasFixedSize(true);
        recy.setLayoutManager(new LinearLayoutManager(context));

        return rootView;
    }

    @Override
    public void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<Products,UserViewHolder> frat = new FirebaseRecyclerAdapter<Products, UserViewHolder>(
                Products.class,
                R.layout.user_hukup,
                UserViewHolder.class,
                mData
        ) {
            @Override
            protected void populateViewHolder(final UserViewHolder viewHolder, Products model, int position) {

                final String user = getRef(position).getKey().toString();

                viewHolder.setName(model.getProduct_name());
                viewHolder.setStat(model.getProduct_date());
                viewHolder.setPic(model.getImage());

                viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        CharSequence options[] = new CharSequence[]{"Product Info","Record Sale","Market Details"};
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Select Option");
                        builder.setItems(options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == 0)
                                {
                                    //view product details
                                }
                                if (which == 1)
                                {
                                    //view analysis info

                                }
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();

                        // Toast.makeText(getActivity().getApplicationContext(),"User id: "+ user,Toast.LENGTH_LONG).show();
                    }
                });
            }
        };
        recy.setAdapter(frat);
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder{
        View mView;

        public UserViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
        }
        public void setName(String name)
        {
            TextView textUser = (TextView) mView.findViewById(R.id.txtUsern);
            textUser.setText(name);

        }

        public void setStat(String status){
            TextView textStat = (TextView)mView.findViewById(R.id.txtHsat);
            textStat.setText(status);
        }

        public void setPic(String image) {
            CircleImageView circ = (CircleImageView)mView.findViewById(R.id.huk_pic);
            Picasso.get().load(image).placeholder(R.drawable.rgt).into(circ);
        }
    }
}
