package com.wordpress.ideatodaybt.plc.Model;

public class IntroProducts {
    public String product_name;
    public String product_date;
    public String image;

    public IntroProducts()
    {

    }

    public IntroProducts(String product_name, String product_date, String image) {
        this.product_name = product_name;
        this.product_date = product_date;
        this.image = image;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_date() {
        return product_date;
    }

    public void setProduct_date(String product_date) {
        this.product_date = product_date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
